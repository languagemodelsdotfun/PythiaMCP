#!/usr/bin/env python3
"""Pythia Voice MCP - Voice interface sidecar for LLM clients."""

# ============================================================================
# IMPORTS
# ============================================================================

from __future__ import annotations

import argparse
import json
import logging
import queue
import sys
import threading
from dataclasses import dataclass, asdict
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional, Callable

import re
import numpy as np
import sounddevice as sd
from fastmcp import FastMCP
from kittentts import KittenTTS
from starlette.responses import PlainTextResponse
from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.reactive import reactive
from textual.screen import ModalScreen, Screen
from textual.widgets import (
    Button,
    Footer,
    Header,
    Input,
    Label,
    ListItem,
    ListView,
    OptionList,
    Select,
    Static,
    Switch,
)
from textual.widgets.option_list import Option

# ============================================================================
# CONSTANTS
# ============================================================================

APP_NAME = "Pythia Voice MCP"
VERSION = "0.1.0"

# Paths
CONFIG_DIR = Path.home() / ".config" / "pythia"
CACHE_DIR = Path.home() / ".cache" / "pythia"
CONFIG_FILE = CONFIG_DIR / "config.json"
LOG_FILE = CACHE_DIR / "pythia.log"
MODELS_DIR = CACHE_DIR / "models"

# Defaults
DEFAULT_PORT = 7984
DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_MAX_LOG_SIZE_MB = 10
LOG_BACKUP_COUNT = 3

# ============================================================================
# CONFIGURATION
# ============================================================================


@dataclass
class PythiaConfig:
    """Application configuration with all settings."""

    # Server
    port: int = DEFAULT_PORT

    # Wake word
    wake_word: str = "Pythia"
    wake_word_position: str = "anywhere"  # "anywhere" or "start"

    # Dictation
    silence_timeout: float = 2.0
    dictation_on_start: bool = False
    whisper_model: str = "base.en"  # Options: tiny.en, base.en, small.en, medium.en, large-v3

    # Logging
    log_level: str = DEFAULT_LOG_LEVEL
    max_log_size_mb: int = DEFAULT_MAX_LOG_SIZE_MB

    # Audio devices (None = system default)
    input_device: Optional[str] = None
    output_device: Optional[str] = None

    # TTS
    tts_voice: str = "expr-voice-2-f"
    tts_speed: float = 1.0
    tts_sentence_gap_ms: int = 150
    tts_lookahead: int = 1
    tts_min_sentence_words: int = 3

    # Text injection
    injection_mode: str = "keyboard"  # "keyboard" or "clipboard"
    keyboard_method: str = "typewrite"  # "typewrite", "paste_gui", "paste_terminal"
    inject_enter: bool = True  # Press ENTER after injecting text

    # Barge-in
    barge_in_enabled: bool = True
    barge_in_threshold: float = 0.7
    barge_in_sustain_ms: int = 300
    tts_barge_in_behavior: str = "immediate"  # "immediate" or "finish_sentence"


def load_config(path: Path = CONFIG_FILE) -> tuple[PythiaConfig, bool]:
    """
    Load configuration from JSON file, creating defaults if missing.

    Returns:
        Tuple of (config, is_first_run)
    """
    if not path.exists():
        config = PythiaConfig()
        save_config(config, path)
        return config, True  # First run

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Create config with loaded values, using defaults for missing keys
        config = PythiaConfig(**{k: v for k, v in data.items() if hasattr(PythiaConfig, k)})
        return config, False  # Not first run
    except (json.JSONDecodeError, TypeError) as e:
        logging.warning(f"Invalid config file, using defaults: {e}")
        return PythiaConfig(), True  # Treat as first run


def save_config(config: PythiaConfig, path: Path = CONFIG_FILE) -> None:
    """Save configuration to JSON file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(asdict(config), f, indent=2)


# System dependencies required for full functionality
SYSTEM_DEPENDENCIES = {
    "xdotool": {
        "required": True,
        "purpose": "text injection into active window",
        "install": "sudo apt install xdotool",
    },
    "espeak-ng": {
        "required": False,
        "purpose": "TTS phoneme generation (fallback)",
        "install": "sudo apt install espeak-ng",
    },
}


def check_system_dependencies(logger: Optional[logging.Logger] = None) -> dict[str, bool]:
    """
    Check if required system dependencies are installed.

    Returns:
        Dict mapping dependency name to installed status.
    """
    results = {}
    for dep, info in SYSTEM_DEPENDENCIES.items():
        path = shutil.which(dep)
        results[dep] = path is not None

        if logger:
            if path:
                logger.info(f"System dependency '{dep}' found: {path}")
            elif info["required"]:
                logger.warning(
                    f"Missing required dependency '{dep}' ({info['purpose']}). "
                    f"Install with: {info['install']}"
                )
            else:
                logger.debug(
                    f"Optional dependency '{dep}' not found ({info['purpose']})"
                )

    return results


def get_missing_dependencies() -> list[tuple[str, str, str]]:
    """
    Get list of missing required dependencies.

    Returns:
        List of (name, purpose, install_command) tuples for missing deps.
    """
    missing = []
    for dep, info in SYSTEM_DEPENDENCIES.items():
        if info["required"] and shutil.which(dep) is None:
            missing.append((dep, info["purpose"], info["install"]))
    return missing


# ============================================================================
# LOGGING
# ============================================================================


def setup_logging(config: PythiaConfig, verbosity: int = 0) -> logging.Logger:
    """
    Set up logging with rotation.

    Args:
        config: Application configuration
        verbosity: 0=config level, 1=INFO, 2+=DEBUG, -1=WARNING only

    Returns:
        Configured logger
    """
    # Ensure log directory exists
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

    # Determine log level based on verbosity
    if verbosity < 0:
        level = logging.WARNING
    elif verbosity == 0:
        level = getattr(logging, config.log_level.upper(), logging.INFO)
    elif verbosity == 1:
        level = logging.INFO
    else:
        level = logging.DEBUG

    # Create logger
    logger = logging.getLogger("pythia")
    logger.setLevel(level)
    logger.handlers.clear()

    # File handler with rotation
    max_bytes = config.max_log_size_mb * 1024 * 1024
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=max_bytes,
        backupCount=LOG_BACKUP_COUNT,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)  # Log everything to file
    file_formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    # Console handler (stderr) - only for warnings and above during normal operation
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(level)
    console_formatter = logging.Formatter("%(levelname)s: %(message)s")
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    logger.debug(f"Logging initialized at level {logging.getLevelName(level)}")
    logger.debug(f"Log file: {LOG_FILE}")

    return logger


# ============================================================================
# CLI ARGUMENT PARSING
# ============================================================================


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        prog="pythia",
        description=f"{APP_NAME} - Voice interface sidecar for LLM clients",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pythia                    Start with default settings
  pythia --port 8000        Use custom port
  pythia -v                 Verbose output (INFO level)
  pythia -vv                Debug output
  pythia --quiet            Only show warnings/errors
""",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {VERSION}",
    )

    parser.add_argument(
        "--port",
        type=int,
        metavar="PORT",
        help=f"MCP server port (default: {DEFAULT_PORT})",
    )

    parser.add_argument(
        "--config",
        type=Path,
        metavar="PATH",
        default=CONFIG_FILE,
        help=f"Config file path (default: {CONFIG_FILE})",
    )

    parser.add_argument(
        "--input-device",
        type=str,
        metavar="DEVICE",
        help="Audio input device name or index",
    )

    parser.add_argument(
        "--output-device",
        type=str,
        metavar="DEVICE",
        help="Audio output device name or index",
    )

    parser.add_argument(
        "--dictation",
        action="store_true",
        help="Enable dictation on startup",
    )

    parser.add_argument(
        "--list-devices",
        action="store_true",
        help="List available audio devices and exit",
    )

    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase verbosity (-v for INFO, -vv for DEBUG)",
    )
    verbosity.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Only show warnings and errors",
    )

    return parser.parse_args()


def apply_cli_overrides(config: PythiaConfig, args: argparse.Namespace) -> PythiaConfig:
    """Apply CLI argument overrides to configuration."""
    if args.port is not None:
        config.port = args.port
    if args.input_device is not None:
        config.input_device = args.input_device
    if args.output_device is not None:
        config.output_device = args.output_device
    if args.dictation:
        config.dictation_on_start = True
    return config


# ============================================================================
# TTS ENGINE (Phase 4)
# ============================================================================

# Abbreviations that shouldn't trigger sentence splits
ABBREVIATIONS = {
    "mr", "mrs", "ms", "dr", "prof", "sr", "jr", "vs", "etc", "inc", "ltd",
    "corp", "co", "st", "ave", "blvd", "rd", "fig", "vol", "no", "pp",
    "e.g", "i.e", "cf", "al", "et"
}

# KittenTTS voices
KITTENTTS_VOICES = [
    "expr-voice-2-f",
    "expr-voice-2-m",
    "expr-voice-3-f",
    "expr-voice-3-m",
    "expr-voice-4-f",
    "expr-voice-4-m",
    "expr-voice-5-f",
    "expr-voice-5-m",
]


def split_sentences(text: str, min_words: int = 3) -> list[str]:
    """
    Split text into sentences for TTS processing.

    Handles common edge cases like abbreviations and decimal numbers.
    Merges short sentences with the next one.
    """
    # Normalize whitespace
    text = " ".join(text.split())

    if not text:
        return []

    sentences = []
    current = []
    words = text.split()

    i = 0
    while i < len(words):
        word = words[i]
        current.append(word)

        # Check if this word ends a sentence
        if word and word[-1] in ".!?":
            # Check for abbreviations
            word_lower = word.rstrip(".!?").lower()
            is_abbrev = word_lower in ABBREVIATIONS

            # Check for decimal numbers (e.g., "3.50")
            is_decimal = (
                word[-1] == "." and
                i + 1 < len(words) and
                words[i + 1][0].isdigit()
            )

            # Check for ellipsis
            is_ellipsis = word.endswith("...")

            if not is_abbrev and not is_decimal and not is_ellipsis:
                # End of sentence
                sentence = " ".join(current).strip()
                if sentence:
                    sentences.append(sentence)
                current = []

        i += 1

    # Add remaining text
    if current:
        sentence = " ".join(current).strip()
        if sentence:
            sentences.append(sentence)

    # Merge short sentences
    if min_words > 1 and len(sentences) > 1:
        merged = []
        i = 0
        while i < len(sentences):
            sent = sentences[i]
            word_count = len(sent.split())

            # If short and not last, merge with next
            if word_count < min_words and i + 1 < len(sentences):
                merged.append(sent + " " + sentences[i + 1])
                i += 2
            else:
                merged.append(sent)
                i += 1
        sentences = merged

    return sentences


class TTSEngine:
    """Text-to-speech engine using KittenTTS."""

    SAMPLE_RATE = 24000  # KittenTTS outputs 24kHz audio

    def __init__(self, config: PythiaConfig):
        self.config = config
        self.logger = logging.getLogger("pythia")
        self._tts: Optional[KittenTTS] = None
        self._is_playing = False
        self._should_stop = False
        self._finish_sentence_and_stop = False  # For "finish_sentence" barge-in behavior
        self._on_playback_start: Optional[Callable[[], None]] = None
        self._on_playback_end: Optional[Callable[[], None]] = None

    def set_playback_callbacks(
        self,
        on_start: Optional[Callable[[], None]] = None,
        on_end: Optional[Callable[[], None]] = None,
    ) -> None:
        """Set callbacks for playback state changes."""
        self._on_playback_start = on_start
        self._on_playback_end = on_end

    def _ensure_tts(self) -> KittenTTS:
        """Lazily initialize the KittenTTS engine."""
        if self._tts is None:
            self.logger.info("Initializing KittenTTS engine...")
            self._tts = KittenTTS()  # Auto-downloads model from HuggingFace
            self.logger.info("KittenTTS engine ready")
        return self._tts

    @property
    def available_voices(self) -> list[str]:
        """Get list of available voice IDs."""
        return KITTENTTS_VOICES.copy()

    def generate_audio(self, text: str, voice: str, speed: float = 1.0) -> Optional[np.ndarray]:
        """
        Generate audio for a single sentence.

        Returns numpy array of audio samples (float32, 24kHz) or None on error.
        """
        if not text.strip():
            return None

        try:
            tts = self._ensure_tts()

            # Generate audio using KittenTTS
            audio = tts.generate(text, voice=voice, speed=speed)
            return audio

        except Exception as e:
            self.logger.error(f"TTS generation error: {e}")
            return None

    def play_audio(self, audio: np.ndarray, device: Optional[str] = None) -> None:
        """
        Play audio through sounddevice.

        Blocks until playback completes or stop() is called.
        """
        if audio is None or len(audio) == 0:
            return

        self._is_playing = True
        self._should_stop = False

        try:
            # Determine output device
            output_device = None
            if device:
                try:
                    output_device = int(device)
                except ValueError:
                    # Device is a name, let sounddevice handle it
                    output_device = device

            # Play audio
            sd.play(audio, samplerate=self.SAMPLE_RATE, device=output_device)

            # Wait for playback with periodic stop checks
            while sd.get_stream() and sd.get_stream().active:
                if self._should_stop:
                    sd.stop()
                    break
                sd.sleep(50)  # Check every 50ms

        except Exception as e:
            self.logger.error(f"Audio playback error: {e}")
        finally:
            self._is_playing = False

    def speak(
        self,
        text: str,
        voice: Optional[str] = None,
        speed: Optional[float] = None,
        on_sentence_start: Optional[Callable[[str], None]] = None,
    ) -> None:
        """
        Speak text with sentence pipelining.

        Generates next sentence while playing current for lower latency.
        """
        voice = voice or self.config.tts_voice
        speed = speed if speed is not None else self.config.tts_speed

        # Split into sentences
        sentences = split_sentences(text, self.config.tts_min_sentence_words)

        if not sentences:
            return

        self.logger.info(f"Speaking {len(sentences)} sentence(s)")

        # Reset stop flags
        self._should_stop = False
        self._finish_sentence_and_stop = False

        # Notify playback start
        if self._on_playback_start:
            self._on_playback_start()

        try:
            # Pipeline: generate next while playing current
            next_audio: Optional[np.ndarray] = None

            for i, sentence in enumerate(sentences):
                if self._should_stop:
                    break

                # Check for "finish sentence and stop" - stop after current sentence
                if self._finish_sentence_and_stop:
                    self.logger.info("Finishing current sentence then stopping")
                    # Play this sentence then break
                    if on_sentence_start:
                        on_sentence_start(sentence)
                    if next_audio is not None:
                        current_audio = next_audio
                    else:
                        current_audio = self.generate_audio(sentence, voice, speed)
                    if current_audio is not None:
                        self.play_audio(current_audio, self.config.output_device)
                    break

                # Notify callback
                if on_sentence_start:
                    on_sentence_start(sentence)

                # Use pre-generated audio or generate now
                if next_audio is not None:
                    current_audio = next_audio
                    next_audio = None
                else:
                    current_audio = self.generate_audio(sentence, voice, speed)

                # Start generating next sentence in background (lookahead=1)
                if i + 1 < len(sentences) and not self._should_stop:
                    # For simplicity, generate synchronously for now
                    next_audio = self.generate_audio(sentences[i + 1], voice, speed)

                # Play current sentence
                if current_audio is not None:
                    self.play_audio(current_audio, self.config.output_device)

                    # Inter-sentence gap
                    if i + 1 < len(sentences) and not self._should_stop:
                        sd.sleep(self.config.tts_sentence_gap_ms)
        finally:
            # Notify playback end
            if self._on_playback_end:
                self._on_playback_end()

    def stop(self, immediate: bool = True) -> None:
        """
        Stop current playback.

        Args:
            immediate: If True, stop immediately. If False, finish current sentence.
        """
        if immediate:
            self._should_stop = True
            try:
                sd.stop()
            except Exception:
                pass
        else:
            # Finish current sentence then stop
            self._finish_sentence_and_stop = True

    def stop_immediate(self) -> None:
        """Stop playback immediately."""
        self.stop(immediate=True)

    def stop_after_sentence(self) -> None:
        """Stop playback after finishing current sentence."""
        self.stop(immediate=False)

    @property
    def is_playing(self) -> bool:
        """Check if audio is currently playing."""
        return self._is_playing

# ============================================================================
# DICTATION ENGINE (Phase 5)
# ============================================================================

# Whisper models available (faster-whisper / CTranslate2 format)
WHISPER_MODELS = [
    "tiny.en", "tiny",
    "base.en", "base",
    "small.en", "small",
    "medium.en", "medium",
    "large-v2", "large-v3",
]

# Audio constants for dictation
DICTATION_SAMPLE_RATE = 16000  # VAD and Whisper both expect 16kHz
VAD_CHUNK_SAMPLES = 512  # Silero VAD requires exactly 512 samples @ 16kHz (32ms)
CAPTURE_CHUNK_MS = 100  # Capture in 100ms chunks, then split for VAD
CAPTURE_SAMPLE_RATE = 48000  # Common capture rate, will resample to 16kHz


class DictationEngine:
    """
    Speech-to-text engine using Silero VAD + Whisper.

    Flow:
    1. Continuously capture audio from microphone
    2. Run VAD to detect speech segments
    3. Accumulate audio during speech
    4. After silence timeout, transcribe with Whisper
    5. Detect wake word and inject text
    """

    def __init__(
        self,
        config: PythiaConfig,
        on_transcription: Optional[Callable[[str, bool], None]] = None,
        on_vad_change: Optional[Callable[[float], None]] = None,
        on_audio_level: Optional[Callable[[float], None]] = None,
    ):
        """
        Initialize dictation engine.

        Args:
            config: Application configuration
            on_transcription: Callback(text, has_wake_word) when transcription completes
            on_vad_change: Callback(probability) for VAD probability updates
            on_audio_level: Callback(level) for audio level updates (0.0-1.0)
        """
        self.config = config
        self.logger = logging.getLogger("pythia")

        # Callbacks
        self.on_transcription = on_transcription
        self.on_vad_change = on_vad_change
        self.on_audio_level = on_audio_level

        # Models (lazy loaded)
        self._vad_model = None
        self._vad_iterator = None
        self._whisper_model = None

        # Recording state
        self._is_running = False
        self._is_recording = False
        self._audio_buffer: list[np.ndarray] = []  # Accumulated 16kHz audio for transcription
        self._vad_buffer: np.ndarray = np.array([], dtype=np.float32)  # Buffer for VAD processing
        self._silence_frames = 0
        self._speech_detected = False

        # VAD threshold (can be elevated during TTS for barge-in)
        self._vad_threshold = 0.5  # Normal threshold
        self._elevated_threshold = False

        # Sustained detection for barge-in
        self._sustained_speech_frames = 0
        self._on_barge_in: Optional[Callable[[], None]] = None

        # Audio stream
        self._stream = None
        self._lock = threading.Lock()
        self._capture_rate = CAPTURE_SAMPLE_RATE  # Will be set based on device

        # Throttle UI updates (don't update every 32ms chunk)
        self._ui_update_counter = 0
        self._ui_update_interval = 3  # Update UI every 3rd chunk (~100ms)

    def _ensure_vad(self):
        """Lazily initialize Silero VAD model."""
        if self._vad_model is None:
            self.logger.info("Loading Silero VAD model...")
            from silero_vad import load_silero_vad, VADIterator
            self._vad_model = load_silero_vad()
            self._vad_iterator = VADIterator(
                self._vad_model,
                threshold=0.5,
                sampling_rate=DICTATION_SAMPLE_RATE,
                min_silence_duration_ms=int(self.config.silence_timeout * 1000),
                speech_pad_ms=30,
            )
            self.logger.info("Silero VAD model ready")

    def _ensure_whisper(self):
        """Lazily initialize Whisper model."""
        if self._whisper_model is None:
            model_name = self.config.whisper_model
            self.logger.info(f"Loading Whisper model ({model_name})...")
            from faster_whisper import WhisperModel

            # Use int8 quantization for CPU speed (4x faster than float32)
            self._whisper_model = WhisperModel(
                model_name,
                device="cpu",
                compute_type="int8",
                cpu_threads=4,
            )
            self.logger.info(f"Whisper model ({model_name}) ready")

    def set_barge_in_callback(self, callback: Optional[Callable[[], None]]) -> None:
        """Set callback for barge-in detection."""
        self._on_barge_in = callback

    def elevate_threshold(self, threshold: float) -> None:
        """Elevate VAD threshold (for barge-in during TTS)."""
        self._vad_threshold = threshold
        self._elevated_threshold = True
        self._sustained_speech_frames = 0
        self.logger.debug(f"VAD threshold elevated to {threshold}")

    def reset_threshold(self) -> None:
        """Reset VAD threshold to normal."""
        self._vad_threshold = 0.5
        self._elevated_threshold = False
        self._sustained_speech_frames = 0
        self.logger.debug("VAD threshold reset to normal")

    def _resample(self, audio: np.ndarray, orig_rate: int, target_rate: int) -> np.ndarray:
        """Resample audio from orig_rate to target_rate."""
        if orig_rate == target_rate:
            return audio

        from scipy import signal
        # Calculate resampling ratio
        num_samples = int(len(audio) * target_rate / orig_rate)
        resampled = signal.resample(audio, num_samples)
        return resampled.astype(np.float32)

    def _get_vad_probability(self, audio: np.ndarray) -> float:
        """Get VAD speech probability for audio chunk."""
        import torch
        self._ensure_vad()

        # Convert to tensor
        if not torch.is_tensor(audio):
            audio_tensor = torch.from_numpy(audio).float()
        else:
            audio_tensor = audio

        # Get probability from model directly
        prob = self._vad_model(audio_tensor, DICTATION_SAMPLE_RATE).item()
        return prob

    def _audio_callback(self, indata, frames, time_info, status):
        """Callback for audio stream - runs in separate thread."""
        if status:
            self.logger.warning(f"Audio stream status: {status}")

        if not self._is_running:
            return

        # Convert to mono float32 if needed
        audio = indata[:, 0].copy() if len(indata.shape) > 1 else indata.copy()
        audio = audio.astype(np.float32)

        # Calculate audio level (RMS) before resampling
        rms = np.sqrt(np.mean(audio ** 2))
        audio_level = min(1.0, rms * 10)  # Scale for display
        # Note: audio_level callback is throttled below with VAD updates

        # Resample to 16kHz for VAD and Whisper
        audio_16k = self._resample(audio, self._capture_rate, DICTATION_SAMPLE_RATE)

        # Add to VAD buffer
        self._vad_buffer = np.concatenate([self._vad_buffer, audio_16k])

        # Process VAD in 512-sample chunks
        while len(self._vad_buffer) >= VAD_CHUNK_SAMPLES:
            # Check if we should stop (allows clean shutdown)
            if not self._is_running:
                return
            chunk = self._vad_buffer[:VAD_CHUNK_SAMPLES]
            self._vad_buffer = self._vad_buffer[VAD_CHUNK_SAMPLES:]

            # Get VAD probability for this chunk
            vad_prob = self._get_vad_probability(chunk)

            # Throttle UI updates to avoid overwhelming the main thread
            self._ui_update_counter += 1
            if self._ui_update_counter >= self._ui_update_interval:
                self._ui_update_counter = 0
                if self.on_vad_change:
                    self.on_vad_change(vad_prob)
                if self.on_audio_level:
                    self.on_audio_level(audio_level)

            with self._lock:
                is_speech = vad_prob >= self._vad_threshold

                # Handle barge-in detection when threshold is elevated
                if self._elevated_threshold and is_speech:
                    self._sustained_speech_frames += 1
                    # Check if sustained speech meets barge-in threshold (32ms per chunk)
                    sustained_ms = self._sustained_speech_frames * 32
                    if sustained_ms >= self.config.barge_in_sustain_ms:
                        self.logger.info(f"Barge-in detected (sustained {sustained_ms}ms)")
                        if self._on_barge_in:
                            self._on_barge_in()
                        self._sustained_speech_frames = 0
                elif self._elevated_threshold:
                    # Reset sustained counter on silence
                    self._sustained_speech_frames = 0

                if is_speech:
                    # Speech detected - store chunk
                    self._speech_detected = True
                    self._silence_frames = 0
                    self._audio_buffer.append(chunk)
                elif self._speech_detected:
                    # In silence after speech - store chunk
                    self._audio_buffer.append(chunk)
                    self._silence_frames += 1

                    # Check if silence timeout reached (32ms per 512-sample chunk)
                    silence_ms = self._silence_frames * 32
                    if silence_ms >= self.config.silence_timeout * 1000:
                        # End of utterance - trigger transcription
                        self._trigger_transcription()

    def _trigger_transcription(self):
        """Transcribe accumulated audio buffer."""
        if not self._audio_buffer:
            return

        # Concatenate audio buffer
        audio = np.concatenate(self._audio_buffer)

        # Reset buffer
        self._audio_buffer = []
        self._speech_detected = False
        self._silence_frames = 0

        # Reset VAD state
        if self._vad_iterator:
            self._vad_iterator.reset_states()

        # Transcribe in background
        threading.Thread(
            target=self._transcribe_audio,
            args=(audio,),
            daemon=True,
        ).start()

    def _transcribe_audio(self, audio: np.ndarray):
        """Transcribe audio with Whisper (runs in background thread)."""
        try:
            self._ensure_whisper()

            self.logger.info(f"Transcribing {len(audio) / DICTATION_SAMPLE_RATE:.1f}s of audio...")

            # Transcribe - faster-whisper returns (segments_generator, info)
            segments, info = self._whisper_model.transcribe(
                audio,
                beam_size=5,
                language="en",
                vad_filter=False,  # We use Silero VAD, not Whisper's built-in
            )

            # Combine segments (segments is a generator)
            text = " ".join(seg.text.strip() for seg in segments).strip()

            if not text:
                self.logger.info("No speech detected in audio")
                return

            self.logger.info(f"Transcription: {text}")

            # Check for wake word
            has_wake_word = self._check_wake_word(text)

            if self.on_transcription:
                self.on_transcription(text, has_wake_word)

        except Exception as e:
            self.logger.error(f"Transcription error: {e}")

    def _check_wake_word(self, text: str) -> bool:
        """Check if text contains wake word."""
        wake_word = self.config.wake_word.lower()
        text_lower = text.lower()

        if self.config.wake_word_position == "start":
            # Wake word must be at the start
            return text_lower.startswith(wake_word)
        else:
            # Wake word can be anywhere
            return wake_word in text_lower

    def extract_text_after_wake_word(self, text: str) -> str:
        """Extract text after the wake word (for injection)."""
        wake_word = self.config.wake_word.lower()
        text_lower = text.lower()

        idx = text_lower.find(wake_word)
        if idx == -1:
            return text

        # Return text after wake word
        result = text[idx + len(wake_word):].strip()

        # Strip leading punctuation and whitespace
        # Whisper often adds punctuation after wake word: "Computer. Hello" -> ". Hello"
        result = result.lstrip('.,;:!?-– ')

        return result

    def inject_text(self, text: str) -> bool:
        """Inject text using configured method."""
        if not text.strip():
            self.logger.warning("inject_text called with empty text")
            return False

        try:
            import pyautogui
            import pyperclip
            import time
            import subprocess
            import shutil

            mode = self.config.injection_mode
            method = self.config.keyboard_method

            self.logger.info(f"Injecting text: mode={mode}, method={method}, text='{text[:50]}...'")

            # Log which window currently has focus (for debugging)
            try:
                focus_result = subprocess.run(['xdotool', 'getactivewindow', 'getwindowname'],
                                              capture_output=True, text=True, timeout=2)
                self.logger.info(f"Active window before injection: {focus_result.stdout.strip()}")
            except Exception as e:
                self.logger.warning(f"Could not get active window: {e}")

            if mode == "clipboard":
                # Copy to clipboard only
                pyperclip.copy(text)
                self.logger.info(f"Text copied to clipboard: {text[:30]}...")
                return True

            # Small delay to allow focus to return to previous window
            # (Pythia TUI may have grabbed focus during processing)
            time.sleep(0.2)  # Increased from 0.1 to 0.2

            # Keyboard injection - try xdotool first on Linux (more reliable)
            xdotool_path = shutil.which("xdotool")

            if method == "typewrite":
                # Try xdotool first (handles Unicode, more reliable on Linux)
                if xdotool_path:
                    try:
                        subprocess.run(
                            ["xdotool", "type", "--clearmodifiers", "--", text],
                            check=True,
                            timeout=10
                        )
                        self.logger.info(f"Text injected via xdotool: {text[:30]}...")
                    except subprocess.SubprocessError as e:
                        self.logger.warning(f"xdotool failed ({e}), falling back to pyautogui")
                        # Fallback to pyautogui (ASCII only on Linux)
                        pyautogui.typewrite(text, interval=0.02)
                else:
                    # No xdotool, use pyautogui
                    pyautogui.typewrite(text, interval=0.02)

            elif method == "paste_gui":
                # Paste via Ctrl+V (faster)
                pyperclip.copy(text)
                time.sleep(0.05)  # Small delay for clipboard sync
                if xdotool_path:
                    subprocess.run(["xdotool", "key", "--clearmodifiers", "ctrl+v"], timeout=5)
                else:
                    pyautogui.hotkey("ctrl", "v")

            elif method == "paste_terminal":
                # Paste via Ctrl+Shift+V (for terminals)
                pyperclip.copy(text)
                time.sleep(0.05)
                if xdotool_path:
                    subprocess.run(["xdotool", "key", "--clearmodifiers", "ctrl+shift+v"], timeout=5)
                else:
                    pyautogui.hotkey("ctrl", "shift", "v")
            else:
                # Fallback to typewrite
                if xdotool_path:
                    subprocess.run(["xdotool", "type", "--clearmodifiers", "--", text], timeout=10)
                else:
                    pyautogui.typewrite(text, interval=0.02)

            self.logger.info(f"Text injected ({method}): {text[:30]}...")

            # Press ENTER after injection if configured
            if self.config.inject_enter:
                time.sleep(0.05)  # Small delay before ENTER
                if xdotool_path:
                    subprocess.run(["xdotool", "key", "--clearmodifiers", "Return"], timeout=5)
                else:
                    pyautogui.press("enter")
                self.logger.info("Pressed ENTER after injection")

            return True

        except Exception as e:
            self.logger.error(f"Text injection error: {type(e).__name__}: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return False

    def start(self, device: Optional[str] = None):
        """Start audio capture and dictation."""
        if self._is_running:
            return

        self._ensure_vad()

        # Determine input device
        input_device = None
        if device:
            try:
                input_device = int(device)
            except ValueError:
                input_device = device
        elif self.config.input_device:
            try:
                input_device = int(self.config.input_device)
            except ValueError:
                input_device = self.config.input_device

        # Get device's native sample rate
        if input_device is not None:
            try:
                dev_info = sd.query_devices(input_device)
                self._capture_rate = int(dev_info["default_samplerate"])
            except Exception:
                self._capture_rate = CAPTURE_SAMPLE_RATE
        else:
            self._capture_rate = CAPTURE_SAMPLE_RATE

        # Calculate block size for capture chunks at device's rate
        capture_block_size = int(self._capture_rate * CAPTURE_CHUNK_MS / 1000)

        self.logger.info(f"Starting dictation (device: {input_device or 'default'}, rate: {self._capture_rate}Hz)")

        # Clear state
        self._audio_buffer = []
        self._vad_buffer = np.array([], dtype=np.float32)
        self._speech_detected = False
        self._silence_frames = 0
        self._is_running = True

        # Reset VAD state
        if self._vad_iterator:
            self._vad_iterator.reset_states()

        # Start audio stream at device's native rate
        self._stream = sd.InputStream(
            samplerate=self._capture_rate,
            channels=1,
            dtype=np.float32,
            blocksize=capture_block_size,
            device=input_device,
            callback=self._audio_callback,
        )
        self._stream.start()

        self.logger.info("Dictation started")

    def stop(self, process_remaining: bool = False):
        """Stop audio capture and dictation.

        Args:
            process_remaining: If True, transcribe any buffered audio before stopping.
                              If False (default), discard buffered audio for fast shutdown.
        """
        if not self._is_running:
            return

        self.logger.info("Stopping dictation...")
        self._is_running = False

        # Stop audio stream
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception as e:
                self.logger.warning(f"Error stopping audio stream: {e}")
            self._stream = None

        # Optionally process any remaining audio (skip for fast shutdown)
        if process_remaining:
            try:
                # Use timeout to avoid hanging
                if self._lock.acquire(timeout=1.0):
                    try:
                        if self._audio_buffer and self._speech_detected:
                            self._trigger_transcription()
                    finally:
                        self._lock.release()
            except Exception as e:
                self.logger.warning(f"Error processing remaining audio: {e}")

        self.logger.info("Dictation stopped")

    @property
    def is_running(self) -> bool:
        """Check if dictation is running."""
        return self._is_running

    def get_input_devices(self) -> list[tuple[int, str]]:
        """Get list of available input devices."""
        devices = []
        for i, dev in enumerate(sd.query_devices()):
            if dev["max_input_channels"] > 0:
                devices.append((i, dev["name"]))
        return devices

    def get_output_devices(self) -> list[tuple[int, str]]:
        """Get list of available output devices."""
        devices = []
        for i, dev in enumerate(sd.query_devices()):
            if dev["max_output_channels"] > 0:
                devices.append((i, dev["name"]))
        return devices

# ============================================================================
# MCP SERVER (Phase 3)
# ============================================================================

# Thread-safe queue for TTS requests (MCP thread -> TTS worker)
tts_queue: queue.Queue = queue.Queue()

# Create FastMCP server instance
mcp = FastMCP(
    "Pythia Voice MCP",
    instructions="""You have access to a text-to-speech tool called 'speak'.

Use the speak tool to:
- Read your responses aloud to the user
- Provide audio feedback for important information

When using speak:
- Keep text concise (1-3 sentences per call for natural pacing)
- Use natural, conversational language
- Available voices: expr-voice-2-f, expr-voice-2-m, expr-voice-3-f, expr-voice-3-m, expr-voice-4-f, expr-voice-4-m, expr-voice-5-f, expr-voice-5-m
- Speed range: 0.5 (slow) to 2.0 (fast), default 1.0"""
)


@mcp.tool
def speak(text: str, voice: str = "expr-voice-2-f", speed: float = 1.0) -> str:
    """
    Speak the given text using text-to-speech.

    Args:
        text: The text to speak aloud
        voice: Voice ID to use (default: expr-voice-2-f). Available: expr-voice-2-f, expr-voice-2-m, expr-voice-3-f, expr-voice-3-m, expr-voice-4-f, expr-voice-4-m, expr-voice-5-f, expr-voice-5-m
        speed: Speech rate multiplier (default: 1.0)

    Returns:
        Confirmation message
    """
    logger = logging.getLogger("pythia")
    logger.info(f"MCP speak() called: {text[:50]}...")

    # Queue the TTS request for the TTS worker
    tts_queue.put({
        "text": text,
        "voice": voice,
        "speed": speed,
    })

    return f"Queued for speech: {text[:50]}{'...' if len(text) > 50 else ''}"


@mcp.custom_route("/health", methods=["GET"])
async def health_check(request) -> PlainTextResponse:
    """Health check endpoint."""
    return PlainTextResponse("OK")


@mcp.prompt(name="voice-response", description="Request a spoken response from the assistant")
def voice_response_prompt() -> str:
    """Prompt the model to use TTS for its response."""
    return """Please respond to the user's message and use the speak tool to read your response aloud.
Keep your spoken response concise and natural-sounding."""


class MCPServerThread(threading.Thread):
    """Background thread for running the MCP server."""

    def __init__(self, host: str, port: int):
        super().__init__(daemon=True)
        self.host = host
        self.port = port
        self.logger = logging.getLogger("pythia")
        self._server = None

    def run(self) -> None:
        """Run the MCP server."""
        self.logger.info(f"Starting MCP server on {self.host}:{self.port}")
        try:
            mcp.run(
                transport="sse",
                host=self.host,
                port=self.port,
            )
        except Exception as e:
            self.logger.error(f"MCP server error: {e}")

# ============================================================================
# TUI COMPONENTS (Phase 2)
# ============================================================================


class HelpScreen(Screen):
    """Help screen with hotkey reference."""

    BINDINGS = [
        Binding("escape", "dismiss", "Close"),
        Binding("q", "dismiss", "Close"),
        Binding("question_mark", "dismiss", "Close"),
    ]

    def compose(self) -> ComposeResult:
        yield Container(
            Static(f"[bold]{APP_NAME} v{VERSION}[/bold]", id="help-title"),
            Static(
                """
[bold]Hotkeys[/bold]

  [cyan]q[/cyan]      Quit application
  [cyan]d[/cyan]      Toggle dictation (start/stop listening)
  [cyan]s[/cyan]      Open Settings
  [cyan]i[/cyan]      Select input device (microphone)
  [cyan]o[/cyan]      Select output device (speakers)
  [cyan]v[/cyan]      Cycle through TTS voices
  [cyan]c[/cyan]      Copy MCP config to clipboard
  [cyan]?[/cyan]      Show this help screen
  [cyan]Up/Down[/cyan] Adjust TTS speed
  [cyan]Space[/cyan]  Skip current TTS playback
  [cyan]^p[/cyan]     Open command palette (themes)

[bold]About[/bold]

Pythia is a voice interface sidecar for LLM clients.
It provides text-to-speech output via MCP and
speech-to-text input via wake word detection.

Press any key to close this help screen.
""",
                id="help-content",
            ),
            Button("Close", id="help-close"),
            id="help-container",
        )

    @on(Button.Pressed, "#help-close")
    def close_help(self) -> None:
        self.dismiss()

    def key_press(self, event) -> None:
        self.dismiss()


class ConfirmQuitModal(ModalScreen[bool]):
    """Modal to confirm quitting the application."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("y", "confirm", "Yes"),
        Binding("n", "cancel", "No"),
    ]

    def compose(self) -> ComposeResult:
        yield Container(
            Static("Are you sure you want to quit?", id="quit-question"),
            Horizontal(
                Button("Yes (y)", variant="error", id="quit-yes"),
                Button("No (n)", variant="primary", id="quit-no"),
                id="quit-buttons",
            ),
            id="quit-container",
        )

    @on(Button.Pressed, "#quit-yes")
    def confirm_quit(self) -> None:
        self.dismiss(True)

    @on(Button.Pressed, "#quit-no")
    def cancel_quit(self) -> None:
        self.dismiss(False)

    def action_confirm(self) -> None:
        self.dismiss(True)

    def action_cancel(self) -> None:
        self.dismiss(False)


class DeviceSelectModal(ModalScreen[Optional[str]]):
    """Modal for selecting audio devices."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    def __init__(
        self,
        device_type: str,
        devices: list[tuple[int, str]],
        current: Optional[str] = None,
    ) -> None:
        super().__init__()
        self.device_type = device_type
        self.devices = devices
        self.current = current

    def compose(self) -> ComposeResult:
        title = f"Select {self.device_type.title()} Device"
        yield Container(
            Static(f"[bold]{title}[/bold]", id="device-title"),
            OptionList(
                *[
                    Option(f"{idx}: {name}", id=str(idx))
                    for idx, name in self.devices
                ],
                id="device-list",
            ),
            Horizontal(
                Button("Default", id="device-default"),
                Button("Cancel", variant="error", id="device-cancel"),
                id="device-buttons",
            ),
            id="device-container",
        )

    @on(OptionList.OptionSelected, "#device-list")
    def device_selected(self, event: OptionList.OptionSelected) -> None:
        if event.option:
            self.dismiss(event.option.id)

    @on(Button.Pressed, "#device-default")
    def select_default(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#device-cancel")
    def cancel_selection(self) -> None:
        self.dismiss(self.current)

    def action_cancel(self) -> None:
        self.dismiss(self.current)


class SettingsModal(ModalScreen[None]):
    """Settings modal with all configuration options."""

    BINDINGS = [
        Binding("escape", "close", "Close"),
    ]

    def __init__(self, config: PythiaConfig, on_save: Callable[[PythiaConfig], None]) -> None:
        super().__init__()
        self.config = config
        self.on_save = on_save

    def compose(self) -> ComposeResult:
        yield Container(
            Static("[bold]Settings[/bold]", id="settings-title"),
            VerticalScroll(
                # Server section
                Static("[bold cyan]Server[/bold cyan]", classes="section-header"),
                Horizontal(
                    Label("MCP Port:"),
                    Input(str(self.config.port), id="port-input", type="integer"),
                    classes="setting-row",
                ),
                # Wake word section
                Static("[bold cyan]Wake Word[/bold cyan]", classes="section-header"),
                Horizontal(
                    Label("Wake Word:"),
                    Input(self.config.wake_word, id="wake-word-input"),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Position:"),
                    Select(
                        [("Anywhere", "anywhere"), ("Start only", "start")],
                        value=self.config.wake_word_position,
                        id="wake-position-select",
                    ),
                    classes="setting-row",
                ),
                # Dictation section
                Static("[bold cyan]Dictation[/bold cyan]", classes="section-header"),
                Horizontal(
                    Label("Whisper Model:"),
                    Select(
                        [
                            ("tiny.en (fastest)", "tiny.en"),
                            ("base.en (fast)", "base.en"),
                            ("small.en (balanced)", "small.en"),
                            ("medium.en (accurate)", "medium.en"),
                            ("large-v3 (best)", "large-v3"),
                        ],
                        value=self.config.whisper_model,
                        id="whisper-model-select",
                    ),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Silence Timeout (s):"),
                    Input(str(self.config.silence_timeout), id="silence-timeout-input"),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Dictation on Start:"),
                    Switch(value=self.config.dictation_on_start, id="dictation-start-switch"),
                    classes="setting-row",
                ),
                # Injection section
                Static("[bold cyan]Text Injection[/bold cyan]", classes="section-header"),
                Horizontal(
                    Label("Mode:"),
                    Select(
                        [("Keyboard", "keyboard"), ("Clipboard", "clipboard")],
                        value=self.config.injection_mode,
                        id="injection-mode-select",
                    ),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Keyboard Method:"),
                    Select(
                        [
                            ("Typewrite", "typewrite"),
                            ("Paste GUI (Ctrl+V)", "paste_gui"),
                            ("Paste Terminal (Ctrl+Shift+V)", "paste_terminal"),
                        ],
                        value=self.config.keyboard_method,
                        id="keyboard-method-select",
                    ),
                    classes="setting-row",
                ),
                # TTS section
                Static("[bold cyan]TTS[/bold cyan]", classes="section-header"),
                Horizontal(
                    Label("Speed:"),
                    Input(str(self.config.tts_speed), id="tts-speed-input"),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Sentence Gap (ms):"),
                    Input(str(self.config.tts_sentence_gap_ms), id="sentence-gap-input", type="integer"),
                    classes="setting-row",
                ),
                # Barge-in section
                Static("[bold cyan]Barge-In[/bold cyan]", classes="section-header"),
                Horizontal(
                    Label("Enabled:"),
                    Switch(value=self.config.barge_in_enabled, id="barge-in-switch"),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Threshold:"),
                    Input(str(self.config.barge_in_threshold), id="barge-threshold-input"),
                    classes="setting-row",
                ),
                Horizontal(
                    Label("Sustain (ms):"),
                    Input(str(self.config.barge_in_sustain_ms), id="barge-sustain-input", type="integer"),
                    classes="setting-row",
                ),
                # Logging section
                Static("[bold cyan]Logging[/bold cyan]", classes="section-header"),
                Horizontal(
                    Label("Log Level:"),
                    Select(
                        [
                            ("DEBUG", "DEBUG"),
                            ("INFO", "INFO"),
                            ("WARNING", "WARNING"),
                            ("ERROR", "ERROR"),
                        ],
                        value=self.config.log_level,
                        id="log-level-select",
                    ),
                    classes="setting-row",
                ),
                id="settings-scroll",
            ),
            Horizontal(
                Button("Save", variant="success", id="settings-save"),
                Button("Cancel", variant="error", id="settings-cancel"),
                id="settings-buttons",
            ),
            id="settings-container",
        )

    @on(Button.Pressed, "#settings-save")
    def save_settings(self) -> None:
        # Collect all values
        try:
            port_input = self.query_one("#port-input", Input)
            self.config.port = int(port_input.value)
        except (ValueError, Exception):
            pass

        try:
            wake_input = self.query_one("#wake-word-input", Input)
            self.config.wake_word = wake_input.value or "Pythia"
        except Exception:
            pass

        try:
            pos_select = self.query_one("#wake-position-select", Select)
            if pos_select.value:
                self.config.wake_word_position = str(pos_select.value)
        except Exception:
            pass

        try:
            silence_input = self.query_one("#silence-timeout-input", Input)
            self.config.silence_timeout = float(silence_input.value)
        except (ValueError, Exception):
            pass

        try:
            dictation_switch = self.query_one("#dictation-start-switch", Switch)
            self.config.dictation_on_start = dictation_switch.value
        except Exception:
            pass

        try:
            whisper_select = self.query_one("#whisper-model-select", Select)
            if whisper_select.value:
                self.config.whisper_model = str(whisper_select.value)
        except Exception:
            pass

        try:
            mode_select = self.query_one("#injection-mode-select", Select)
            if mode_select.value:
                self.config.injection_mode = str(mode_select.value)
        except Exception:
            pass

        try:
            method_select = self.query_one("#keyboard-method-select", Select)
            if method_select.value:
                self.config.keyboard_method = str(method_select.value)
        except Exception:
            pass

        try:
            speed_input = self.query_one("#tts-speed-input", Input)
            self.config.tts_speed = float(speed_input.value)
        except (ValueError, Exception):
            pass

        try:
            gap_input = self.query_one("#sentence-gap-input", Input)
            self.config.tts_sentence_gap_ms = int(gap_input.value)
        except (ValueError, Exception):
            pass

        try:
            barge_switch = self.query_one("#barge-in-switch", Switch)
            self.config.barge_in_enabled = barge_switch.value
        except Exception:
            pass

        try:
            thresh_input = self.query_one("#barge-threshold-input", Input)
            self.config.barge_in_threshold = float(thresh_input.value)
        except (ValueError, Exception):
            pass

        try:
            sustain_input = self.query_one("#barge-sustain-input", Input)
            self.config.barge_in_sustain_ms = int(sustain_input.value)
        except (ValueError, Exception):
            pass

        try:
            log_select = self.query_one("#log-level-select", Select)
            if log_select.value:
                self.config.log_level = str(log_select.value)
        except Exception:
            pass

        self.on_save(self.config)
        self.dismiss()

    @on(Button.Pressed, "#settings-cancel")
    def cancel_settings(self) -> None:
        self.dismiss()

    def action_close(self) -> None:
        self.dismiss()


# ============================================================================
# MAIN APPLICATION (Phase 2)
# ============================================================================


class PythiaApp(App):
    """Main Pythia Voice MCP application."""

    CSS_PATH = "pythia.tcss"

    BINDINGS = [
        Binding("q", "request_quit", "Quit"),
        Binding("d", "toggle_dictation", "Dictation"),
        Binding("s", "open_settings", "Settings"),
        Binding("i", "open_input_devices", "Input"),
        Binding("o", "open_output_devices", "Output"),
        Binding("v", "cycle_voice", "Voice"),
        Binding("c", "copy_mcp_config", "Copy"),
        Binding("question_mark", "open_help", "Help"),
        Binding("up", "increase_speed", "Speed+", show=False),
        Binding("down", "decrease_speed", "Speed-", show=False),
        Binding("space", "skip_tts", "Skip", show=False),
    ]

    # Reactive state
    server_status = reactive("Starting...")
    dictation_active = reactive(False)
    current_voice = reactive("expr-voice-2-f")
    tts_speed = reactive(1.0)
    vad_probability = reactive(0.0)
    audio_level = reactive(0.0)
    log_message = reactive("Ready")

    def __init__(self, config: PythiaConfig, config_path: Path, is_first_run: bool = False) -> None:
        super().__init__()
        self.config = config
        self.config_path = config_path
        self._is_first_run = is_first_run
        self.logger = logging.getLogger("pythia")
        self.current_voice = config.tts_voice
        self.tts_speed = config.tts_speed
        self._mcp_server: Optional[MCPServerThread] = None
        self._tts_worker_running = False
        self._tts_engine: Optional[TTSEngine] = None
        self._dictation_engine: Optional[DictationEngine] = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield Container(
            Static(self._get_mcp_json(), id="mcp-json"),
            Static("", id="server-status"),
            Static("", id="status-line"),
            Static("", id="log-line"),
            id="main-container",
        )
        yield Footer()

    def on_mount(self) -> None:
        self.title = APP_NAME
        self.sub_title = f"v{VERSION}"
        self._update_status_displays()

        # Initialize TTS engine with playback callbacks
        self._tts_engine = TTSEngine(self.config)
        self._tts_engine.set_playback_callbacks(
            on_start=self._on_tts_playback_start,
            on_end=self._on_tts_playback_end,
        )

        # Initialize dictation engine with callbacks
        self._dictation_engine = DictationEngine(
            self.config,
            on_transcription=self._on_transcription,
            on_vad_change=self._on_vad_change,
            on_audio_level=self._on_audio_level,
        )
        # Set barge-in callback
        self._dictation_engine.set_barge_in_callback(self._on_barge_in)

        # Start MCP server in background thread
        self._start_mcp_server()

        # Start TTS queue consumer worker
        self._start_tts_worker()

        # Handle first run - check dependencies and show settings modal
        if self._is_first_run:
            # Check system dependencies on first run
            check_system_dependencies(self.logger)
            missing = get_missing_dependencies()
            if missing:
                deps_str = ", ".join(f"'{d[0]}'" for d in missing)
                self.log_message = f"Warning: Missing {deps_str}. See logs."
            else:
                self.log_message = "Welcome! Configure your settings."
            self.call_later(self._show_first_run_settings)
        else:
            self.log_message = "Ready - Press ? for help"

            # Start with dictation if configured
            if self.config.dictation_on_start:
                self.dictation_active = True
                self._start_dictation()

    def _show_first_run_settings(self) -> None:
        """Show settings modal on first run."""
        def save_first_run_config(config: PythiaConfig) -> None:
            self.config = config
            save_config(config, self.config_path)
            self.current_voice = config.tts_voice
            self.tts_speed = config.tts_speed
            self.log_message = "Settings saved! Ready - Press ? for help"
            self.logger.info("First-run settings saved")

            # Start dictation if configured after first run setup
            if self.config.dictation_on_start:
                self.dictation_active = True
                self._start_dictation()

        self.push_screen(SettingsModal(self.config, save_first_run_config))

    def _start_mcp_server(self) -> None:
        """Start the MCP server in a background thread."""
        self._mcp_server = MCPServerThread("127.0.0.1", self.config.port)
        self._mcp_server.start()
        self.server_status = f"Running | http://127.0.0.1:{self.config.port}/sse"
        self.logger.info(f"MCP server started on port {self.config.port}")

    @work(thread=True)
    def _start_tts_worker(self) -> None:
        """Background worker to consume TTS queue and perform TTS."""
        self._tts_worker_running = True
        self.logger.info("TTS worker started")

        while self._tts_worker_running:
            try:
                # Wait for TTS request with timeout
                request = tts_queue.get(timeout=0.5)

                # Process TTS in this worker thread
                self._process_tts_request(request)

                tts_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"TTS worker error: {e}")

    def _process_tts_request(self, request: dict) -> None:
        """Process a TTS request (runs in worker thread)."""
        text = request.get("text", "")
        voice = request.get("voice", self.current_voice)
        speed = request.get("speed", self.tts_speed)

        # Update UI
        self.call_from_thread(self._update_tts_status, f"Speaking: {text[:30]}...")

        self.logger.info(f"Processing TTS: voice={voice}, speed={speed}")

        # Perform TTS
        if self._tts_engine:
            def on_sentence(sentence: str) -> None:
                self.call_from_thread(self._update_tts_status, f"TTS: {sentence[:30]}...")

            self._tts_engine.speak(text, voice=voice, speed=speed, on_sentence_start=on_sentence)

        # Update UI when done
        self.call_from_thread(self._update_tts_status, "Ready")

    def _update_tts_status(self, message: str) -> None:
        """Update TTS status in UI (called from main thread)."""
        self.log_message = message

    def _start_dictation(self) -> None:
        """Start dictation engine."""
        if self._dictation_engine and not self._dictation_engine.is_running:
            self._dictation_engine.start()
            self.logger.info("Dictation started")

    def _stop_dictation(self) -> None:
        """Stop dictation engine."""
        if self._dictation_engine and self._dictation_engine.is_running:
            self._dictation_engine.stop()
            self.logger.info("Dictation stopped")

    def _on_transcription(self, text: str, has_wake_word: bool) -> None:
        """Handle transcription result from dictation engine."""
        self.call_from_thread(self._handle_transcription, text, has_wake_word)

    def _handle_transcription(self, text: str, has_wake_word: bool) -> None:
        """Handle transcription in main thread."""
        if has_wake_word:
            # Extract text after wake word and inject
            if self._dictation_engine:
                inject_text = self._dictation_engine.extract_text_after_wake_word(text)
                if inject_text:
                    self.log_message = f"Wake word! Injecting: {inject_text[:30]}..."

                    # Stop TTS if playing (barge-in)
                    if self.config.barge_in_enabled and self._tts_engine and self._tts_engine.is_playing:
                        self._tts_engine.stop()
                        self.logger.info("Barge-in: stopped TTS")

                    # Inject text in background thread to avoid blocking UI
                    self.run_worker(
                        lambda: self._dictation_engine.inject_text(inject_text),
                        thread=True
                    )
                else:
                    self.log_message = f"Wake word detected (no text to inject)"
        else:
            self.log_message = f"Heard: {text[:40]}..."

    def _on_vad_change(self, probability: float) -> None:
        """Handle VAD probability update from dictation engine."""
        self.call_from_thread(self._update_vad, probability)

    def _update_vad(self, probability: float) -> None:
        """Update VAD probability in main thread."""
        self.vad_probability = probability

    def _on_audio_level(self, level: float) -> None:
        """Handle audio level update from dictation engine."""
        self.call_from_thread(self._update_audio_level, level)

    def _update_audio_level(self, level: float) -> None:
        """Update audio level in main thread."""
        self.audio_level = level

    def _on_tts_playback_start(self) -> None:
        """Called when TTS playback starts."""
        self.logger.debug("TTS playback started")
        # Elevate VAD threshold for barge-in detection
        if self.config.barge_in_enabled and self._dictation_engine:
            self._dictation_engine.elevate_threshold(self.config.barge_in_threshold)

    def _on_tts_playback_end(self) -> None:
        """Called when TTS playback ends."""
        self.logger.debug("TTS playback ended")
        # Reset VAD threshold to normal
        if self._dictation_engine:
            self._dictation_engine.reset_threshold()

    def _on_barge_in(self) -> None:
        """Called when barge-in is detected (sustained speech during TTS)."""
        if not self.config.barge_in_enabled:
            return

        self.call_from_thread(self._handle_barge_in)

    def _handle_barge_in(self) -> None:
        """Handle barge-in in main thread."""
        self.log_message = "Barge-in detected!"
        self.logger.info(f"Handling barge-in (behavior: {self.config.tts_barge_in_behavior})")

        if self._tts_engine:
            if self.config.tts_barge_in_behavior == "immediate":
                self._tts_engine.stop_immediate()
            else:  # "finish_sentence"
                self._tts_engine.stop_after_sentence()

    def _get_mcp_json(self) -> str:
        config_json = {
            "mcpServers": {
                "pythia": {
                    "url": f"http://127.0.0.1:{self.config.port}/sse"
                }
            }
        }
        return json.dumps(config_json, indent=2)

    def _get_vu_meter(self, level: float) -> str:
        """Generate VU meter string from audio level (0.0 - 1.0)."""
        blocks = "▁▂▃▄▅▆▇█"
        num_blocks = 8
        filled = int(level * num_blocks)
        return "".join(blocks[min(i, len(blocks) - 1)] for i in range(filled))

    def _update_status_displays(self) -> None:
        """Update all status display widgets."""
        # Update server status
        try:
            server_widget = self.query_one("#server-status", Static)
            server_widget.update(f"Server: {self.server_status}")
        except Exception:
            pass

        # Update status line
        try:
            status_widget = self.query_one("#status-line", Static)
            vu_meter = self._get_vu_meter(self.audio_level)
            dictation_status = "ON" if self.dictation_active else "OFF"
            status_widget.update(
                f"Voice: {self.current_voice} | "
                f"Speed: {self.tts_speed:.1f}x | "
                f"VAD: {self.vad_probability:.2f} | "
                f"Vol: {vu_meter or '▁'} | "
                f"Dictation: {dictation_status}"
            )
        except Exception:
            pass

        # Update log line
        try:
            log_widget = self.query_one("#log-line", Static)
            log_widget.update(f"Log: {self.log_message}")
        except Exception:
            pass

    def watch_server_status(self, value: str) -> None:
        self._update_status_displays()

    def watch_dictation_active(self, value: bool) -> None:
        self._update_status_displays()
        self.log_message = f"Dictation {'enabled' if value else 'disabled'}"

    def watch_current_voice(self, value: str) -> None:
        self._update_status_displays()

    def watch_tts_speed(self, value: float) -> None:
        self._update_status_displays()

    def watch_vad_probability(self, value: float) -> None:
        self._update_status_displays()

    def watch_audio_level(self, value: float) -> None:
        self._update_status_displays()

    def watch_log_message(self, value: str) -> None:
        self._update_status_displays()

    def action_request_quit(self) -> None:
        """Show quit confirmation."""
        def handle_quit(result: bool) -> None:
            if result:
                self._cleanup_and_exit()

        self.push_screen(ConfirmQuitModal(), handle_quit)

    def _cleanup_and_exit(self) -> None:
        """Clean up resources and exit."""
        # Stop dictation
        if self._dictation_engine:
            self._dictation_engine.stop()

        # Stop TTS
        if self._tts_engine:
            self._tts_engine.stop()

        # Stop TTS worker
        self._tts_worker_running = False

        self.exit()

    def action_toggle_dictation(self) -> None:
        """Toggle dictation on/off."""
        self.dictation_active = not self.dictation_active

        if self.dictation_active:
            self._start_dictation()
        else:
            self._stop_dictation()

        self.logger.info(f"Dictation {'enabled' if self.dictation_active else 'disabled'}")

    def action_open_settings(self) -> None:
        """Open settings modal."""
        def on_settings_save(config: PythiaConfig) -> None:
            self.config = config
            save_config(config, self.config_path)
            self.current_voice = config.tts_voice
            self.tts_speed = config.tts_speed
            self.log_message = "Settings saved"
            self.logger.info("Settings saved")
            # Update MCP JSON display with new port
            try:
                mcp_widget = self.query_one("#mcp-json", Static)
                mcp_widget.update(self._get_mcp_json())
            except Exception:
                pass

        self.push_screen(SettingsModal(self.config, on_settings_save))

    def action_open_input_devices(self) -> None:
        """Open input device selection modal."""
        # Get real input devices from dictation engine
        if self._dictation_engine:
            devices = self._dictation_engine.get_input_devices()
        else:
            devices = [(0, "Default Input")]

        def handle_selection(device: Optional[str]) -> None:
            if device is not None:
                self.config.input_device = device
                save_config(self.config, self.config_path)
                self.log_message = f"Input device: {device}"
                self.logger.info(f"Input device set to: {device}")

                # Restart dictation with new device if active
                if self.dictation_active:
                    self._stop_dictation()
                    self._start_dictation()

        self.push_screen(
            DeviceSelectModal("input", devices, self.config.input_device),
            handle_selection,
        )

    def action_open_output_devices(self) -> None:
        """Open output device selection modal."""
        # Get real output devices from dictation engine (or TTS engine)
        if self._dictation_engine:
            devices = self._dictation_engine.get_output_devices()
        else:
            devices = [(0, "Default Output")]

        def handle_selection(device: Optional[str]) -> None:
            if device is not None:
                self.config.output_device = device
                save_config(self.config, self.config_path)
                self.log_message = f"Output device: {device}"
                self.logger.info(f"Output device set to: {device}")

        self.push_screen(
            DeviceSelectModal("output", devices, self.config.output_device),
            handle_selection,
        )

    def action_cycle_voice(self) -> None:
        """Cycle through available TTS voices."""
        voices = KITTENTTS_VOICES
        try:
            current_idx = voices.index(self.current_voice)
            next_idx = (current_idx + 1) % len(voices)
        except ValueError:
            next_idx = 0

        self.current_voice = voices[next_idx]
        self.config.tts_voice = self.current_voice
        save_config(self.config, self.config_path)
        self.log_message = f"Voice: {self.current_voice}"
        self.logger.info(f"Voice changed to: {self.current_voice}")

    def action_copy_mcp_config(self) -> None:
        """Copy MCP config JSON to clipboard."""
        try:
            import pyperclip
            pyperclip.copy(self._get_mcp_json())
            self.log_message = "MCP config copied to clipboard"
            self.logger.info("MCP config copied to clipboard")
        except ImportError:
            self.log_message = "pyperclip not installed"
            self.logger.warning("pyperclip not installed for clipboard")
        except Exception as e:
            self.log_message = f"Copy failed: {e}"
            self.logger.error(f"Clipboard copy failed: {e}")

    def action_open_help(self) -> None:
        """Open help screen."""
        self.push_screen(HelpScreen())

    def action_increase_speed(self) -> None:
        """Increase TTS speed."""
        new_speed = min(2.0, self.tts_speed + 0.1)
        self.tts_speed = round(new_speed, 1)
        self.config.tts_speed = self.tts_speed
        save_config(self.config, self.config_path)
        self.log_message = f"Speed: {self.tts_speed}x"

    def action_decrease_speed(self) -> None:
        """Decrease TTS speed."""
        new_speed = max(0.5, self.tts_speed - 0.1)
        self.tts_speed = round(new_speed, 1)
        self.config.tts_speed = self.tts_speed
        save_config(self.config, self.config_path)
        self.log_message = f"Speed: {self.tts_speed}x"

    def action_skip_tts(self) -> None:
        """Skip current TTS playback."""
        if self._tts_engine:
            self._tts_engine.stop()
        self.log_message = "TTS skipped"
        self.logger.info("TTS skip requested")


# ============================================================================
# ENTRY POINT
# ============================================================================


def list_audio_devices() -> None:
    """List all available audio devices."""
    print(f"\n{APP_NAME} - Audio Devices\n")
    print("=" * 60)

    devices = sd.query_devices()

    print("\n[INPUT DEVICES (Microphones)]")
    print("-" * 40)
    for i, dev in enumerate(devices):
        if dev["max_input_channels"] > 0:
            default = " (default)" if i == sd.default.device[0] else ""
            print(f"  {i:2d}: {dev['name']}{default}")

    print("\n[OUTPUT DEVICES (Speakers)]")
    print("-" * 40)
    for i, dev in enumerate(devices):
        if dev["max_output_channels"] > 0:
            default = " (default)" if i == sd.default.device[1] else ""
            print(f"  {i:2d}: {dev['name']}{default}")

    print("\n" + "=" * 60)
    print("Usage: pythia --input-device <ID> --output-device <ID>")
    print()


def main() -> int:
    """Main entry point."""
    args = parse_args()

    # Handle --list-devices
    if args.list_devices:
        list_audio_devices()
        return 0

    # Load and apply configuration
    config, is_first_run = load_config(args.config)
    config = apply_cli_overrides(config, args)

    # Set up logging
    verbosity = -1 if args.quiet else args.verbose
    logger = setup_logging(config, verbosity)

    logger.info(f"Starting {APP_NAME} v{VERSION}")
    logger.info(f"Config file: {args.config}")
    logger.info(f"Port: {config.port}")

    # Ensure required directories exist
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    # Run the Textual application
    app = PythiaApp(config, args.config, is_first_run=is_first_run)
    app.run()

    logger.info("Application exited normally")
    return 0


if __name__ == "__main__":
    sys.exit(main())
